import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { BarcodeScanner } from "./barcode-scanner";
import { apiRequest } from "@/lib/queryClient";
import type { ProductWithDetails } from "@shared/schema";

interface QuickSaleModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SaleItem {
  product: ProductWithDetails;
  quantity: number;
  unitPrice: number;
  totalPrice: number;
}

export function QuickSaleModal({ isOpen, onClose }: QuickSaleModalProps) {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [items, setItems] = useState<SaleItem[]>([]);
  const [paymentMethod, setPaymentMethod] = useState<string>("");
  const [isScanning, setIsScanning] = useState(false);

  const createSaleMutation = useMutation({
    mutationFn: async (saleData: any) => {
      const response = await apiRequest("POST", "/api/sales", saleData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Sale Completed",
        description: "Transaction has been processed successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/sales"] });
      handleClose();
    },
    onError: () => {
      toast({
        title: "Sale Failed",
        description: "Unable to process the transaction. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleAddProduct = async (productId: string) => {
    try {
      const response = await fetch(`/api/products/${productId}`);
      if (!response.ok) throw new Error("Product not found");
      
      const product: ProductWithDetails = await response.json();
      
      const existingItem = items.find(item => item.product.id === productId);
      if (existingItem) {
        setItems(items.map(item => 
          item.product.id === productId 
            ? { ...item, quantity: item.quantity + 1, totalPrice: (item.quantity + 1) * item.unitPrice }
            : item
        ));
      } else {
        const newItem: SaleItem = {
          product,
          quantity: 1,
          unitPrice: parseFloat(product.price),
          totalPrice: parseFloat(product.price),
        };
        setItems([...items, newItem]);
      }
    } catch (error) {
      toast({
        title: "Product Not Found",
        description: "Unable to add product to sale.",
        variant: "destructive",
      });
    }
  };

  const handleProductFound = (product: ProductWithDetails) => {
    handleAddProduct(product.id);
    setIsScanning(false);
  };

  const handleRemoveItem = (productId: string) => {
    setItems(items.filter(item => item.product.id !== productId));
  };

  const handleQuantityChange = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      handleRemoveItem(productId);
      return;
    }
    
    setItems(items.map(item => 
      item.product.id === productId 
        ? { ...item, quantity, totalPrice: quantity * item.unitPrice }
        : item
    ));
  };

  const calculateTotal = () => {
    return items.reduce((sum, item) => sum + item.totalPrice, 0);
  };

  const handleCompleteSale = () => {
    if (!user || items.length === 0 || !paymentMethod) {
      toast({
        title: "Invalid Sale",
        description: "Please add items and select a payment method.",
        variant: "destructive",
      });
      return;
    }

    const subtotal = calculateTotal();
    const tax = subtotal * 0.1; // 10% tax
    const total = subtotal + tax;

    const saleData = {
      sale: {
        userId: user.id,
        subtotal: subtotal.toFixed(2),
        tax: tax.toFixed(2),
        discount: "0.00",
        total: total.toFixed(2),
        paymentMethod,
      },
      items: items.map(item => ({
        productId: item.product.id,
        quantity: item.quantity,
        unitPrice: item.unitPrice.toFixed(2),
        totalPrice: item.totalPrice.toFixed(2),
      })),
    };

    createSaleMutation.mutate(saleData);
  };

  const handleClose = () => {
    setItems([]);
    setPaymentMethod("");
    setIsScanning(false);
    onClose();
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={handleClose}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-auto" data-testid="quick-sale-modal">
          <DialogHeader>
            <DialogTitle>Quick Sale</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Barcode Scanner */}
            <div className="space-y-2">
              <Label>Scan Barcode or Enter SKU</Label>
              <div className="flex space-x-2">
                <Button 
                  variant="outline" 
                  onClick={() => setIsScanning(true)}
                  data-testid="button-scan-barcode"
                >
                  <i className="fas fa-barcode mr-2"></i>
                  Scan Barcode
                </Button>
              </div>
            </div>

            {/* Selected Items */}
            <div className="space-y-2">
              <Label>Selected Items</Label>
              <div className="border border-border rounded-md max-h-64 overflow-y-auto">
                {items.length === 0 ? (
                  <div className="p-4 bg-muted/20">
                    <p className="text-sm text-muted-foreground text-center">
                      Scan items to add them to the sale
                    </p>
                  </div>
                ) : (
                  <div className="divide-y divide-border">
                    {items.map((item) => (
                      <div key={item.product.id} className="p-3 flex items-center justify-between" data-testid={`sale-item-${item.product.id}`}>
                        <div className="flex-1">
                          <p className="text-sm font-medium">{item.product.name}</p>
                          <p className="text-xs text-muted-foreground">SKU: {item.product.sku}</p>
                        </div>
                        <div className="flex items-center space-x-3">
                          <div className="flex items-center space-x-2">
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => handleQuantityChange(item.product.id, item.quantity - 1)}
                              data-testid={`button-decrease-${item.product.id}`}
                            >
                              -
                            </Button>
                            <Input
                              type="number"
                              value={item.quantity}
                              onChange={(e) => handleQuantityChange(item.product.id, parseInt(e.target.value) || 0)}
                              className="w-16 text-center"
                              min="1"
                              data-testid={`input-quantity-${item.product.id}`}
                            />
                            <Button 
                              size="sm" 
                              variant="outline"
                              onClick={() => handleQuantityChange(item.product.id, item.quantity + 1)}
                              data-testid={`button-increase-${item.product.id}`}
                            >
                              +
                            </Button>
                          </div>
                          <span className="text-sm font-semibold w-20 text-right">
                            ${item.totalPrice.toFixed(2)}
                          </span>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleRemoveItem(item.product.id)}
                            data-testid={`button-remove-${item.product.id}`}
                          >
                            <i className="fas fa-trash"></i>
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Payment Method */}
            <div className="space-y-2">
              <Label>Payment Method</Label>
              <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                <SelectTrigger data-testid="select-payment-method">
                  <SelectValue placeholder="Select payment method" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="card">Card</SelectItem>
                  <SelectItem value="digital">Digital</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Footer */}
          <div className="flex items-center justify-between pt-4 border-t border-border">
            <div>
              <p className="text-sm text-muted-foreground">Total</p>
              <p className="text-2xl font-bold text-foreground" data-testid="text-total">
                ${(calculateTotal() * 1.1).toFixed(2)}
              </p>
              <p className="text-xs text-muted-foreground">
                Subtotal: ${calculateTotal().toFixed(2)} + Tax: ${(calculateTotal() * 0.1).toFixed(2)}
              </p>
            </div>
            <div className="flex space-x-3">
              <Button variant="outline" onClick={handleClose} data-testid="button-cancel">
                Cancel
              </Button>
              <Button
                onClick={handleCompleteSale}
                disabled={items.length === 0 || !paymentMethod || createSaleMutation.isPending}
                data-testid="button-complete-sale"
              >
                {createSaleMutation.isPending ? "Processing..." : "Complete Sale"}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <BarcodeScanner
        isOpen={isScanning}
        onClose={() => setIsScanning(false)}
        onProductFound={handleProductFound}
      />
    </>
  );
}
