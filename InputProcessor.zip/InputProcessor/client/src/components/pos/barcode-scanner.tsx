import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import type { ProductWithDetails } from "@shared/schema";

interface BarcodeScannerProps {
  isOpen: boolean;
  onClose: () => void;
  onProductFound: (product: ProductWithDetails) => void;
}

export function BarcodeScanner({ isOpen, onClose, onProductFound }: BarcodeScannerProps) {
  const [searchValue, setSearchValue] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const { toast } = useToast();

  const handleSearch = async () => {
    if (!searchValue.trim()) return;
    
    setIsSearching(true);
    try {
      // Try searching by barcode first, then by SKU
      let response = await fetch(`/api/products/barcode/${encodeURIComponent(searchValue)}`);
      
      if (!response.ok) {
        response = await fetch(`/api/products/sku/${encodeURIComponent(searchValue)}`);
      }
      
      if (!response.ok) {
        toast({
          title: "Product Not Found",
          description: `No product found with barcode/SKU: ${searchValue}`,
          variant: "destructive",
        });
        return;
      }
      
      const product: ProductWithDetails = await response.json();
      onProductFound(product);
      setSearchValue("");
      onClose();
    } catch (error) {
      toast({
        title: "Search Error",
        description: "Unable to search for product. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSearching(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSearch();
    }
  };

  const handleClose = () => {
    setSearchValue("");
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="max-w-md" data-testid="barcode-scanner-modal">
        <DialogHeader>
          <DialogTitle>Scan Product</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="barcode-input">Barcode or SKU</Label>
            <Input
              id="barcode-input"
              type="text"
              placeholder="Scan barcode or enter SKU..."
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
              onKeyPress={handleKeyPress}
              autoFocus
              data-testid="input-barcode"
            />
          </div>
          
          <div className="text-center p-4 border border-dashed border-border rounded-lg">
            <i className="fas fa-barcode text-4xl text-muted-foreground mb-2"></i>
            <p className="text-sm text-muted-foreground">
              Use a barcode scanner or manually enter the product code
            </p>
          </div>
          
          <div className="flex justify-end space-x-2">
            <Button variant="outline" onClick={handleClose} data-testid="button-cancel-scan">
              Cancel
            </Button>
            <Button 
              onClick={handleSearch}
              disabled={!searchValue.trim() || isSearching}
              data-testid="button-search-product"
            >
              {isSearching ? "Searching..." : "Find Product"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
