import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const navigationItems = [
  { icon: "fas fa-tachometer-alt", label: "Dashboard", path: "/" },
  { icon: "fas fa-cash-register", label: "Point of Sale", path: "/pos" },
  { icon: "fas fa-box", label: "Products", path: "/products" },
  { icon: "fas fa-warehouse", label: "Inventory", path: "/inventory" },
  { icon: "fas fa-users", label: "Customers", path: "/customers" },
  { icon: "fas fa-truck", label: "Suppliers", path: "/suppliers" },
  { icon: "fas fa-chart-bar", label: "Reports", path: "/reports" },
  { icon: "fas fa-cog", label: "Settings", path: "/settings" },
];

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  return (
    <div className="w-64 bg-card border-r border-border flex flex-col" data-testid="sidebar">
      {/* Logo and Company Name */}
      <div className="p-6 border-b border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <i className="fas fa-store text-primary-foreground text-lg"></i>
          </div>
          <div>
            <h1 className="text-lg font-semibold text-foreground">RetailPOS</h1>
            <p className="text-sm text-muted-foreground">Inventory Manager</p>
          </div>
        </div>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 p-4 space-y-2">
        {navigationItems.map((item) => (
          <Link key={item.path} href={item.path}>
            <a
              className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-md font-medium transition-colors",
                location === item.path
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              )}
              data-testid={`nav-${item.label.toLowerCase().replace(" ", "-")}`}
            >
              <i className={`${item.icon} w-5`}></i>
              <span>{item.label}</span>
            </a>
          </Link>
        ))}
      </nav>

      {/* User Profile */}
      <div className="p-4 border-t border-border">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center">
            <i className="fas fa-user text-secondary-foreground"></i>
          </div>
          <div className="flex-1">
            <p className="text-sm font-medium text-foreground" data-testid="user-name">
              {user?.firstName} {user?.lastName}
            </p>
            <p className="text-xs text-muted-foreground capitalize" data-testid="user-role">
              {user?.role}
            </p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={logout}
            data-testid="button-logout"
          >
            <i className="fas fa-sign-out-alt"></i>
          </Button>
        </div>
      </div>
    </div>
  );
}
