import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { QuickSaleModal } from "@/components/pos/quick-sale-modal";

interface TopBarProps {
  title: string;
  subtitle: string;
}

export function TopBar({ title, subtitle }: TopBarProps) {
  const [isQuickSaleOpen, setIsQuickSaleOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: searchResults } = useQuery({
    queryKey: ["/api/search", { q: searchQuery }],
    enabled: searchQuery.length > 2,
  });

  return (
    <>
      <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between" data-testid="topbar">
        <div>
          <h2 className="text-2xl font-semibold text-foreground" data-testid="page-title">
            {title}
          </h2>
          <p className="text-sm text-muted-foreground" data-testid="page-subtitle">
            {subtitle}
          </p>
        </div>

        <div className="flex items-center space-x-4">
          {/* Search */}
          <div className="relative">
            <Input
              type="text"
              placeholder="Search products, customers..."
              className="w-64 pl-10"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              data-testid="input-search"
            />
            <i className="fas fa-search absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground"></i>
            
            {/* Search Results Dropdown */}
            {searchResults && searchResults.length > 0 && (
              <div className="absolute top-full mt-1 w-full bg-popover border border-border rounded-md shadow-lg z-50 max-h-64 overflow-y-auto">
                {searchResults.map((result: any) => (
                  <div
                    key={`${result.type}-${result.id}`}
                    className="p-3 hover:bg-accent cursor-pointer"
                    data-testid={`search-result-${result.type}-${result.id}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-medium">{result.name || `${result.firstName} ${result.lastName}`}</span>
                      <Badge variant="secondary" className="text-xs">
                        {result.type}
                      </Badge>
                    </div>
                    {result.sku && (
                      <p className="text-xs text-muted-foreground">SKU: {result.sku}</p>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Notifications */}
          <Button variant="ghost" size="sm" data-testid="button-notifications">
            <div className="relative">
              <i className="fas fa-bell text-lg"></i>
              <Badge className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground text-xs w-5 h-5 rounded-full flex items-center justify-center p-0">
                3
              </Badge>
            </div>
          </Button>

          {/* Quick Sale Button */}
          <Button 
            onClick={() => setIsQuickSaleOpen(true)}
            data-testid="button-quick-sale"
          >
            <i className="fas fa-plus mr-2"></i>
            Quick Sale
          </Button>
        </div>
      </header>

      <QuickSaleModal 
        isOpen={isQuickSaleOpen} 
        onClose={() => setIsQuickSaleOpen(false)} 
      />
    </>
  );
}
