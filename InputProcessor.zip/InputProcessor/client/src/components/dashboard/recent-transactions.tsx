import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import type { SaleWithDetails } from "@shared/schema";

export function RecentTransactions() {
  const { data: transactions, isLoading } = useQuery<SaleWithDetails[]>({
    queryKey: ["/api/dashboard/recent-transactions"],
  });

  if (isLoading) {
    return (
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Recent Transactions</h3>
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => (
            <div key={i} className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
              <div className="flex items-center space-x-3">
                <Skeleton className="w-8 h-8 rounded-full" />
                <div>
                  <Skeleton className="h-4 w-20 mb-1" />
                  <Skeleton className="h-3 w-16" />
                </div>
              </div>
              <Skeleton className="h-4 w-12" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  const getTransactionIcon = (status: string) => {
    switch (status) {
      case "refunded":
        return { icon: "fas fa-undo", color: "bg-destructive" };
      case "cancelled":
        return { icon: "fas fa-times", color: "bg-muted" };
      default:
        return { icon: "fas fa-shopping-cart", color: "bg-chart-1" };
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const minutes = Math.floor(diff / (1000 * 60));
    
    if (minutes < 60) {
      return `${minutes} minutes ago`;
    } else if (minutes < 1440) {
      return `${Math.floor(minutes / 60)} hours ago`;
    } else {
      return `${Math.floor(minutes / 1440)} days ago`;
    }
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">Recent Transactions</h3>
        <Link href="/reports">
          <Button variant="ghost" size="sm" data-testid="button-view-all-transactions">
            View All
          </Button>
        </Link>
      </div>
      
      <div className="space-y-4" data-testid="recent-transactions-list">
        {transactions?.length === 0 ? (
          <div className="p-4 bg-muted/20 rounded-lg text-center">
            <p className="text-sm text-muted-foreground">No recent transactions</p>
          </div>
        ) : (
          transactions?.map((transaction) => {
            const iconInfo = getTransactionIcon(transaction.status);
            return (
              <div
                key={transaction.id}
                className="flex items-center justify-between p-3 bg-muted/20 rounded-lg"
                data-testid={`transaction-${transaction.transactionId}`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-8 h-8 ${iconInfo.color} rounded-full flex items-center justify-center`}>
                    <i className={`${iconInfo.icon} text-white text-sm`}></i>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">
                      {transaction.transactionId}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatTime(transaction.createdAt)}
                    </p>
                  </div>
                </div>
                <span className={`text-sm font-semibold ${
                  transaction.status === "refunded" ? "text-destructive" : "text-foreground"
                }`}>
                  {transaction.status === "refunded" ? "-" : ""}${parseFloat(transaction.total).toFixed(2)}
                </span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
