import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import type { ProductWithDetails } from "@shared/schema";

export function LowStockAlerts() {
  const { data: lowStockProducts, isLoading } = useQuery<ProductWithDetails[]>({
    queryKey: ["/api/dashboard/low-stock"],
  });

  if (isLoading) {
    return (
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Low Stock Alerts</h3>
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex items-center justify-between p-3 bg-destructive/5 border border-destructive/20 rounded-lg">
              <div className="flex items-center space-x-3">
                <Skeleton className="w-10 h-10 rounded-lg" />
                <div>
                  <Skeleton className="h-4 w-32 mb-1" />
                  <Skeleton className="h-3 w-20" />
                </div>
              </div>
              <div className="text-right">
                <Skeleton className="h-4 w-12 mb-1" />
                <Skeleton className="h-3 w-8" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">Low Stock Alerts</h3>
        <Link href="/inventory">
          <Button variant="ghost" size="sm" data-testid="button-view-all-alerts">
            View All
          </Button>
        </Link>
      </div>
      
      <div className="space-y-3" data-testid="low-stock-alerts-list">
        {lowStockProducts?.length === 0 ? (
          <div className="p-4 bg-muted/20 rounded-lg text-center">
            <i className="fas fa-check-circle text-chart-1 text-2xl mb-2"></i>
            <p className="text-sm text-muted-foreground">All products are well stocked!</p>
          </div>
        ) : (
          lowStockProducts?.slice(0, 5).map((product) => (
            <div
              key={product.id}
              className="flex items-center justify-between p-3 bg-destructive/5 border border-destructive/20 rounded-lg"
              data-testid={`low-stock-product-${product.id}`}
            >
              <div className="flex items-center space-x-3">
                <div className="w-10 h-10 bg-destructive/10 rounded-lg flex items-center justify-center">
                  <i className="fas fa-exclamation-triangle text-destructive"></i>
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground">
                    {product.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    SKU: {product.sku}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-semibold text-destructive">
                  {product.stock} left
                </p>
                <p className="text-xs text-muted-foreground">
                  Min: {product.minStock}
                </p>
              </div>
            </div>
          ))
        )}
      </div>
      
      {lowStockProducts && lowStockProducts.length > 5 && (
        <div className="mt-4 text-center">
          <Link href="/inventory">
            <Button variant="outline" size="sm">
              View {lowStockProducts.length - 5} more alerts
            </Button>
          </Link>
        </div>
      )}
    </div>
  );
}
