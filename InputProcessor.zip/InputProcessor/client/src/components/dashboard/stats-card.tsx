interface StatsCardProps {
  title: string;
  value: string;
  change: string;
  changeType: "positive" | "negative" | "neutral";
  icon: string;
  iconColor: string;
}

export function StatsCard({ title, value, change, changeType, icon, iconColor }: StatsCardProps) {
  const getChangeColor = () => {
    switch (changeType) {
      case "positive":
        return "text-chart-1";
      case "negative":
        return "text-destructive";
      default:
        return "text-muted-foreground";
    }
  };

  const getChangeIcon = () => {
    switch (changeType) {
      case "positive":
        return "fas fa-arrow-up";
      case "negative":
        return "fas fa-arrow-down";
      default:
        return "fas fa-minus";
    }
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6" data-testid={`stats-card-${title.toLowerCase().replace(/\s+/g, "-")}`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          <p className="text-2xl font-bold text-foreground" data-testid={`value-${title.toLowerCase().replace(/\s+/g, "-")}`}>
            {value}
          </p>
          <p className={`text-sm mt-1 ${getChangeColor()}`}>
            <i className={`${getChangeIcon()} mr-1`}></i>
            <span>{change}</span>
          </p>
        </div>
        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${iconColor}/10`}>
          <i className={`${icon} ${iconColor} text-xl`}></i>
        </div>
      </div>
    </div>
  );
}
