import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import type { Product } from "@shared/schema";

type TopProduct = Product & { soldQuantity: number; revenue: number };

export function TopProducts() {
  const { data: topProducts, isLoading } = useQuery<TopProduct[]>({
    queryKey: ["/api/dashboard/top-products"],
  });

  if (isLoading) {
    return (
      <div className="bg-card rounded-lg border border-border p-6">
        <h3 className="text-lg font-semibold text-foreground mb-4">Top Selling Products</h3>
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex items-center justify-between p-3 bg-muted/20 rounded-lg">
              <div className="flex items-center space-x-3">
                <Skeleton className="w-10 h-10 rounded-lg" />
                <div>
                  <Skeleton className="h-4 w-32 mb-1" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
              <Skeleton className="h-4 w-16" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1:
        return "text-chart-1 bg-chart-1/10";
      case 2:
        return "text-chart-2 bg-chart-2/10";
      case 3:
        return "text-chart-3 bg-chart-3/10";
      default:
        return "text-muted-foreground bg-muted/20";
    }
  };

  return (
    <div className="bg-card rounded-lg border border-border p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">Top Selling Products</h3>
        <Link href="/reports">
          <Button variant="ghost" size="sm" data-testid="button-view-product-analytics">
            View Analytics
          </Button>
        </Link>
      </div>
      
      <div className="space-y-3" data-testid="top-products-list">
        {topProducts?.length === 0 ? (
          <div className="p-4 bg-muted/20 rounded-lg text-center">
            <p className="text-sm text-muted-foreground">No sales data available</p>
          </div>
        ) : (
          topProducts?.slice(0, 5).map((product, index) => {
            const rank = index + 1;
            const rankColorClass = getRankColor(rank);
            
            return (
              <div
                key={product.id}
                className="flex items-center justify-between p-3 bg-muted/20 rounded-lg"
                data-testid={`top-product-${product.id}`}
              >
                <div className="flex items-center space-x-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${rankColorClass}`}>
                    <span className="font-bold text-sm">{rank}</span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">
                      {product.name}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {product.soldQuantity} sold this month
                    </p>
                  </div>
                </div>
                <span className="text-sm font-semibold text-foreground">
                  ${product.revenue.toFixed(0)}
                </span>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
