import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { withAuth } from "@/lib/auth";
import { Sidebar } from "@/components/layout/sidebar";
import { TopBar } from "@/components/layout/topbar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { SaleWithDetails, DashboardStats } from "@shared/schema";

function ReportsPage() {
  const [dateRange, setDateRange] = useState("7");
  const [activeTab, setActiveTab] = useState("sales");

  const { data: stats } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  const { data: sales, isLoading: salesLoading } = useQuery<SaleWithDetails[]>({
    queryKey: ["/api/sales"],
  });

  const { data: topProducts } = useQuery({
    queryKey: ["/api/dashboard/top-products"],
  });

  const getDateRangeLabel = (days: string) => {
    switch (days) {
      case "1":
        return "Today";
      case "7":
        return "Last 7 Days";
      case "30":
        return "Last 30 Days";
      case "90":
        return "Last 90 Days";
      default:
        return "All Time";
    }
  };

  const calculateSalesMetrics = () => {
    if (!sales) return { totalSales: 0, totalTransactions: 0, averageOrder: 0 };
    
    const totalSales = sales.reduce((sum, sale) => sum + parseFloat(sale.total), 0);
    const totalTransactions = sales.length;
    const averageOrder = totalTransactions > 0 ? totalSales / totalTransactions : 0;
    
    return { totalSales, totalTransactions, averageOrder };
  };

  const { totalSales, totalTransactions, averageOrder } = calculateSalesMetrics();

  const exportToCSV = () => {
    if (!sales) return;
    
    const headers = ["Transaction ID", "Date", "Customer", "Items", "Total", "Payment Method"];
    const csvContent = [
      headers.join(","),
      ...sales.map(sale => [
        sale.transactionId,
        new Date(sale.createdAt).toLocaleDateString(),
        sale.customer ? `${sale.customer.firstName} ${sale.customer.lastName}` : "Walk-in",
        sale.items.length,
        sale.total,
        sale.paymentMethod
      ].join(","))
    ].join("\n");
    
    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `sales-report-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar 
          title="Reports" 
          subtitle="Analyze your business performance and sales data." 
        />
        
        <main className="flex-1 overflow-auto p-6 bg-background">
          {/* Report Controls */}
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <Select value={dateRange} onValueChange={setDateRange}>
                <SelectTrigger className="w-40" data-testid="select-date-range">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Today</SelectItem>
                  <SelectItem value="7">Last 7 Days</SelectItem>
                  <SelectItem value="30">Last 30 Days</SelectItem>
                  <SelectItem value="90">Last 90 Days</SelectItem>
                  <SelectItem value="all">All Time</SelectItem>
                </SelectContent>
              </Select>
              <Badge variant="outline">{getDateRangeLabel(dateRange)}</Badge>
            </div>
            
            <div className="flex space-x-2">
              <Button variant="outline" onClick={exportToCSV} data-testid="button-export-csv">
                <i className="fas fa-download mr-2"></i>
                Export CSV
              </Button>
              <Button variant="outline" data-testid="button-print-report">
                <i className="fas fa-print mr-2"></i>
                Print
              </Button>
            </div>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
                <i className="fas fa-dollar-sign text-chart-1"></i>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${totalSales.toFixed(2)}</div>
                <p className="text-xs text-muted-foreground">
                  For {getDateRangeLabel(dateRange).toLowerCase()}
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
                <i className="fas fa-shopping-cart text-chart-2"></i>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{totalTransactions}</div>
                <p className="text-xs text-muted-foreground">
                  Orders processed
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Average Order</CardTitle>
                <i className="fas fa-chart-line text-chart-3"></i>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">${averageOrder.toFixed(2)}</div>
                <p className="text-xs text-muted-foreground">
                  Per transaction
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Report Tabs */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList>
              <TabsTrigger value="sales" data-testid="tab-sales">Sales Report</TabsTrigger>
              <TabsTrigger value="products" data-testid="tab-products">Product Performance</TabsTrigger>
              <TabsTrigger value="inventory" data-testid="tab-inventory">Inventory Report</TabsTrigger>
            </TabsList>
            
            <TabsContent value="sales" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Sales Transactions</CardTitle>
                </CardHeader>
                <CardContent>
                  {salesLoading ? (
                    <div className="text-center py-8">
                      <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
                    </div>
                  ) : (
                    <div className="overflow-x-auto">
                      <Table>
                        <TableHeader>
                          <TableRow>
                            <TableHead>Transaction ID</TableHead>
                            <TableHead>Date</TableHead>
                            <TableHead>Customer</TableHead>
                            <TableHead>Items</TableHead>
                            <TableHead>Payment</TableHead>
                            <TableHead>Total</TableHead>
                            <TableHead>Status</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {sales?.slice(0, 50).map((sale) => (
                            <TableRow key={sale.id} data-testid={`sale-row-${sale.id}`}>
                              <TableCell className="font-medium">{sale.transactionId}</TableCell>
                              <TableCell>{new Date(sale.createdAt).toLocaleDateString()}</TableCell>
                              <TableCell>
                                {sale.customer 
                                  ? `${sale.customer.firstName} ${sale.customer.lastName}`
                                  : "Walk-in Customer"
                                }
                              </TableCell>
                              <TableCell>{sale.items.length} items</TableCell>
                              <TableCell className="capitalize">{sale.paymentMethod}</TableCell>
                              <TableCell>${parseFloat(sale.total).toFixed(2)}</TableCell>
                              <TableCell>
                                <Badge variant={
                                  sale.status === "completed" ? "default" :
                                  sale.status === "refunded" ? "destructive" : "secondary"
                                }>
                                  {sale.status}
                                </Badge>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                      
                      {sales?.length === 0 && (
                        <div className="text-center py-8">
                          <i className="fas fa-chart-bar text-4xl text-muted-foreground mb-4"></i>
                          <p className="text-muted-foreground">No sales data available for the selected period.</p>
                        </div>
                      )}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="products" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Top Performing Products</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {topProducts?.map((product: any, index: number) => (
                      <div key={product.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div className="flex items-center space-x-4">
                          <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                            <span className="text-primary font-bold">{index + 1}</span>
                          </div>
                          <div>
                            <p className="font-medium">{product.name}</p>
                            <p className="text-sm text-muted-foreground">SKU: {product.sku}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">{product.soldQuantity} sold</p>
                          <p className="text-sm text-muted-foreground">${product.revenue.toFixed(2)} revenue</p>
                        </div>
                      </div>
                    ))}
                    
                    {topProducts?.length === 0 && (
                      <div className="text-center py-8">
                        <i className="fas fa-box text-4xl text-muted-foreground mb-4"></i>
                        <p className="text-muted-foreground">No product sales data available.</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="inventory" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Inventory Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center py-8">
                    <i className="fas fa-warehouse text-4xl text-muted-foreground mb-4"></i>
                    <h3 className="text-lg font-semibold mb-2">Inventory Report</h3>
                    <p className="text-muted-foreground">
                      Detailed inventory reporting features coming soon.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}

export default withAuth(ReportsPage);
