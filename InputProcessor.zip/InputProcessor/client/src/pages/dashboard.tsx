import { useQuery } from "@tanstack/react-query";
import { withAuth } from "@/lib/auth";
import { Sidebar } from "@/components/layout/sidebar";
import { TopBar } from "@/components/layout/topbar";
import { StatsCard } from "@/components/dashboard/stats-card";
import { RecentTransactions } from "@/components/dashboard/recent-transactions";
import { LowStockAlerts } from "@/components/dashboard/low-stock-alerts";
import { TopProducts } from "@/components/dashboard/top-products";
import { Skeleton } from "@/components/ui/skeleton";
import type { DashboardStats } from "@shared/schema";

function DashboardPage() {
  const { data: stats, isLoading: statsLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar 
          title="Dashboard" 
          subtitle="Welcome back! Here's what's happening in your store today." 
        />
        
        <main className="flex-1 overflow-auto p-6 bg-background">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {statsLoading ? (
              [...Array(4)].map((_, i) => (
                <div key={i} className="bg-card rounded-lg border border-border p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <Skeleton className="h-4 w-24 mb-2" />
                      <Skeleton className="h-8 w-20 mb-2" />
                      <Skeleton className="h-3 w-32" />
                    </div>
                    <Skeleton className="w-12 h-12 rounded-lg" />
                  </div>
                </div>
              ))
            ) : (
              <>
                <StatsCard
                  title="Today's Sales"
                  value={`$${stats?.todaySales.toFixed(2) || "0.00"}`}
                  change={`${stats?.salesGrowth >= 0 ? "+" : ""}${stats?.salesGrowth.toFixed(1) || "0.0"}% from yesterday`}
                  changeType={stats?.salesGrowth >= 0 ? "positive" : "negative"}
                  icon="fas fa-dollar-sign"
                  iconColor="text-chart-1"
                />
                <StatsCard
                  title="Total Products"
                  value={stats?.totalProducts.toString() || "0"}
                  change={`${stats?.productGrowth >= 0 ? "+" : ""}${stats?.productGrowth.toFixed(1) || "0.0"}% this month`}
                  changeType={stats?.productGrowth >= 0 ? "positive" : "negative"}
                  icon="fas fa-box"
                  iconColor="text-chart-2"
                />
                <StatsCard
                  title="Low Stock Items"
                  value={stats?.lowStockItems.toString() || "0"}
                  change="Requires attention"
                  changeType={stats?.lowStockItems > 0 ? "negative" : "positive"}
                  icon="fas fa-exclamation-triangle"
                  iconColor="text-destructive"
                />
                <StatsCard
                  title="Active Customers"
                  value={stats?.activeCustomers.toString() || "0"}
                  change={`+${stats?.customerGrowth.toFixed(1) || "0.0"}% this week`}
                  changeType="positive"
                  icon="fas fa-users"
                  iconColor="text-chart-3"
                />
              </>
            )}
          </div>

          {/* Charts and Recent Activity Row */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
            {/* Sales Chart Placeholder */}
            <div className="lg:col-span-2 bg-card rounded-lg border border-border p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-foreground">Sales Overview</h3>
                <div className="flex space-x-2">
                  <button className="px-3 py-1 text-sm bg-primary text-primary-foreground rounded-md">
                    Daily
                  </button>
                  <button className="px-3 py-1 text-sm text-muted-foreground hover:text-foreground">
                    Weekly
                  </button>
                  <button className="px-3 py-1 text-sm text-muted-foreground hover:text-foreground">
                    Monthly
                  </button>
                </div>
              </div>
              <div className="h-64 flex items-center justify-center bg-muted/20 rounded-lg">
                <div className="text-center">
                  <i className="fas fa-chart-line text-4xl text-muted-foreground mb-2"></i>
                  <p className="text-muted-foreground">Sales chart visualization</p>
                  <p className="text-sm text-muted-foreground">Chart integration pending</p>
                </div>
              </div>
            </div>

            <RecentTransactions />
          </div>

          {/* Products and Alerts Row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <LowStockAlerts />
            <TopProducts />
          </div>
        </main>
      </div>
    </div>
  );
}

export default withAuth(DashboardPage);
