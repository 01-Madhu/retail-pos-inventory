import { withAuth } from "@/lib/auth";
import { Sidebar } from "@/components/layout/sidebar";
import { TopBar } from "@/components/layout/topbar";

function CustomersPage() {
  return (
    <div className="flex h-screen bg-background">
      <Sidebar />
      
      <div className="flex-1 flex flex-col overflow-hidden">
        <TopBar 
          title="Customers" 
          subtitle="Manage customer relationships and purchase history." 
        />
        
        <main className="flex-1 overflow-auto p-6 bg-background">
          <div className="text-center py-12">
            <i className="fas fa-users text-6xl text-muted-foreground mb-4"></i>
            <h2 className="text-2xl font-semibold text-foreground mb-2">
              Customer Management
            </h2>
            <p className="text-muted-foreground">
              Customer database and CRM features coming soon.
            </p>
          </div>
        </main>
      </div>
    </div>
  );
}

export default withAuth(CustomersPage);
