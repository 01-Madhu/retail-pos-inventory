import { type User, type InsertUser, type Product, type InsertProduct, type Category, type InsertCategory, type Supplier, type InsertSupplier, type Customer, type InsertCustomer, type Sale, type InsertSale, type SaleItem, type InsertSaleItem, type InventoryAdjustment, type InsertInventoryAdjustment, type ProductWithDetails, type SaleWithDetails, type DashboardStats } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;
  getUsers(): Promise<User[]>;

  // Category methods
  getCategories(): Promise<Category[]>;
  getCategory(id: string): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: string, category: Partial<InsertCategory>): Promise<Category | undefined>;
  deleteCategory(id: string): Promise<boolean>;

  // Supplier methods
  getSuppliers(): Promise<Supplier[]>;
  getSupplier(id: string): Promise<Supplier | undefined>;
  createSupplier(supplier: InsertSupplier): Promise<Supplier>;
  updateSupplier(id: string, supplier: Partial<InsertSupplier>): Promise<Supplier | undefined>;
  deleteSupplier(id: string): Promise<boolean>;

  // Product methods
  getProducts(): Promise<ProductWithDetails[]>;
  getProduct(id: string): Promise<ProductWithDetails | undefined>;
  getProductBySku(sku: string): Promise<ProductWithDetails | undefined>;
  getProductByBarcode(barcode: string): Promise<ProductWithDetails | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: string, product: Partial<InsertProduct>): Promise<Product | undefined>;
  deleteProduct(id: string): Promise<boolean>;
  getLowStockProducts(): Promise<ProductWithDetails[]>;
  updateProductStock(productId: string, quantity: number, userId: string, type: string, reason?: string): Promise<boolean>;

  // Customer methods
  getCustomers(): Promise<Customer[]>;
  getCustomer(id: string): Promise<Customer | undefined>;
  createCustomer(customer: InsertCustomer): Promise<Customer>;
  updateCustomer(id: string, customer: Partial<InsertCustomer>): Promise<Customer | undefined>;
  deleteCustomer(id: string): Promise<boolean>;
  searchCustomers(query: string): Promise<Customer[]>;

  // Sale methods
  getSales(): Promise<SaleWithDetails[]>;
  getSale(id: string): Promise<SaleWithDetails | undefined>;
  createSale(sale: InsertSale, items: InsertSaleItem[]): Promise<Sale>;
  getSalesByDateRange(startDate: Date, endDate: Date): Promise<SaleWithDetails[]>;
  getRecentTransactions(limit?: number): Promise<SaleWithDetails[]>;

  // Inventory methods
  getInventoryAdjustments(): Promise<InventoryAdjustment[]>;
  createInventoryAdjustment(adjustment: InsertInventoryAdjustment): Promise<InventoryAdjustment>;

  // Dashboard methods
  getDashboardStats(): Promise<DashboardStats>;
  getTopSellingProducts(limit?: number): Promise<(Product & { soldQuantity: number; revenue: number })[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private categories: Map<string, Category>;
  private suppliers: Map<string, Supplier>;
  private products: Map<string, Product>;
  private customers: Map<string, Customer>;
  private sales: Map<string, Sale>;
  private saleItems: Map<string, SaleItem>;
  private inventoryAdjustments: Map<string, InventoryAdjustment>;

  constructor() {
    this.users = new Map();
    this.categories = new Map();
    this.suppliers = new Map();
    this.products = new Map();
    this.customers = new Map();
    this.sales = new Map();
    this.saleItems = new Map();
    this.inventoryAdjustments = new Map();

    // Initialize with default admin user
    this.initializeDefaultData();
  }

  private initializeDefaultData() {
    // Create default admin user with proper bcrypt hash for "admin123"
    const adminUser: User = {
      id: randomUUID(),
      username: "admin",
      password: "$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi", // password: admin123
      email: "admin@retailpos.com",
      role: "admin",
      firstName: "System",
      lastName: "Administrator",
      isActive: true,
      createdAt: new Date(),
    };
    this.users.set(adminUser.id, adminUser);

    // Create sample categories
    const categories = [
      { name: "Electronics", description: "Electronic devices and accessories" },
      { name: "Accessories", description: "Phone and computer accessories" },
      { name: "Audio", description: "Speakers, headphones, and audio equipment" }
    ];

    for (const cat of categories) {
      const category: Category = {
        id: randomUUID(),
        ...cat,
        createdAt: new Date(),
      };
      this.categories.set(category.id, category);
    }

    // Create sample supplier
    const supplier: Supplier = {
      id: randomUUID(),
      name: "Tech Distributors Inc",
      contactPerson: "John Wilson",
      email: "orders@techdist.com",
      phone: "+1-555-0123",
      address: "123 Business Ave, Tech City, TC 12345",
      createdAt: new Date(),
    };
    this.suppliers.set(supplier.id, supplier);
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: string): Promise<boolean> {
    return this.users.delete(id);
  }

  async getUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Category methods
  async getCategories(): Promise<Category[]> {
    return Array.from(this.categories.values());
  }

  async getCategory(id: string): Promise<Category | undefined> {
    return this.categories.get(id);
  }

  async createCategory(insertCategory: InsertCategory): Promise<Category> {
    const id = randomUUID();
    const category: Category = {
      ...insertCategory,
      id,
      createdAt: new Date(),
    };
    this.categories.set(id, category);
    return category;
  }

  async updateCategory(id: string, categoryData: Partial<InsertCategory>): Promise<Category | undefined> {
    const category = this.categories.get(id);
    if (!category) return undefined;
    
    const updatedCategory = { ...category, ...categoryData };
    this.categories.set(id, updatedCategory);
    return updatedCategory;
  }

  async deleteCategory(id: string): Promise<boolean> {
    return this.categories.delete(id);
  }

  // Supplier methods
  async getSuppliers(): Promise<Supplier[]> {
    return Array.from(this.suppliers.values());
  }

  async getSupplier(id: string): Promise<Supplier | undefined> {
    return this.suppliers.get(id);
  }

  async createSupplier(insertSupplier: InsertSupplier): Promise<Supplier> {
    const id = randomUUID();
    const supplier: Supplier = {
      ...insertSupplier,
      id,
      createdAt: new Date(),
    };
    this.suppliers.set(id, supplier);
    return supplier;
  }

  async updateSupplier(id: string, supplierData: Partial<InsertSupplier>): Promise<Supplier | undefined> {
    const supplier = this.suppliers.get(id);
    if (!supplier) return undefined;
    
    const updatedSupplier = { ...supplier, ...supplierData };
    this.suppliers.set(id, updatedSupplier);
    return updatedSupplier;
  }

  async deleteSupplier(id: string): Promise<boolean> {
    return this.suppliers.delete(id);
  }

  // Product methods
  async getProducts(): Promise<ProductWithDetails[]> {
    const products = Array.from(this.products.values());
    return products.map(product => ({
      ...product,
      category: product.categoryId ? this.categories.get(product.categoryId) : undefined,
      supplier: product.supplierId ? this.suppliers.get(product.supplierId) : undefined,
    }));
  }

  async getProduct(id: string): Promise<ProductWithDetails | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    
    return {
      ...product,
      category: product.categoryId ? this.categories.get(product.categoryId) : undefined,
      supplier: product.supplierId ? this.suppliers.get(product.supplierId) : undefined,
    };
  }

  async getProductBySku(sku: string): Promise<ProductWithDetails | undefined> {
    const product = Array.from(this.products.values()).find(p => p.sku === sku);
    if (!product) return undefined;
    
    return {
      ...product,
      category: product.categoryId ? this.categories.get(product.categoryId) : undefined,
      supplier: product.supplierId ? this.suppliers.get(product.supplierId) : undefined,
    };
  }

  async getProductByBarcode(barcode: string): Promise<ProductWithDetails | undefined> {
    const product = Array.from(this.products.values()).find(p => p.barcode === barcode);
    if (!product) return undefined;
    
    return {
      ...product,
      category: product.categoryId ? this.categories.get(product.categoryId) : undefined,
      supplier: product.supplierId ? this.suppliers.get(product.supplierId) : undefined,
    };
  }

  async createProduct(insertProduct: InsertProduct): Promise<Product> {
    const id = randomUUID();
    const product: Product = {
      ...insertProduct,
      id,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.products.set(id, product);
    return product;
  }

  async updateProduct(id: string, productData: Partial<InsertProduct>): Promise<Product | undefined> {
    const product = this.products.get(id);
    if (!product) return undefined;
    
    const updatedProduct = { 
      ...product, 
      ...productData,
      updatedAt: new Date(),
    };
    this.products.set(id, updatedProduct);
    return updatedProduct;
  }

  async deleteProduct(id: string): Promise<boolean> {
    return this.products.delete(id);
  }

  async getLowStockProducts(): Promise<ProductWithDetails[]> {
    const products = await this.getProducts();
    return products.filter(product => product.stock <= product.minStock);
  }

  async updateProductStock(productId: string, quantity: number, userId: string, type: string, reason?: string): Promise<boolean> {
    const product = this.products.get(productId);
    if (!product) return false;

    const previousStock = product.stock;
    const newStock = previousStock + quantity;

    // Update product stock
    const updatedProduct = { ...product, stock: newStock, updatedAt: new Date() };
    this.products.set(productId, updatedProduct);

    // Create inventory adjustment record
    const adjustment: InventoryAdjustment = {
      id: randomUUID(),
      productId,
      userId,
      type,
      quantity,
      previousStock,
      newStock,
      reason,
      createdAt: new Date(),
    };
    this.inventoryAdjustments.set(adjustment.id, adjustment);

    return true;
  }

  // Customer methods
  async getCustomers(): Promise<Customer[]> {
    return Array.from(this.customers.values());
  }

  async getCustomer(id: string): Promise<Customer | undefined> {
    return this.customers.get(id);
  }

  async createCustomer(insertCustomer: InsertCustomer): Promise<Customer> {
    const id = randomUUID();
    const customer: Customer = {
      ...insertCustomer,
      id,
      loyaltyPoints: 0,
      totalPurchases: "0",
      createdAt: new Date(),
    };
    this.customers.set(id, customer);
    return customer;
  }

  async updateCustomer(id: string, customerData: Partial<InsertCustomer>): Promise<Customer | undefined> {
    const customer = this.customers.get(id);
    if (!customer) return undefined;
    
    const updatedCustomer = { ...customer, ...customerData };
    this.customers.set(id, updatedCustomer);
    return updatedCustomer;
  }

  async deleteCustomer(id: string): Promise<boolean> {
    return this.customers.delete(id);
  }

  async searchCustomers(query: string): Promise<Customer[]> {
    const customers = Array.from(this.customers.values());
    const searchTerm = query.toLowerCase();
    
    return customers.filter(customer => 
      customer.firstName.toLowerCase().includes(searchTerm) ||
      customer.lastName.toLowerCase().includes(searchTerm) ||
      customer.email?.toLowerCase().includes(searchTerm) ||
      customer.phone?.includes(searchTerm)
    );
  }

  // Sale methods
  async getSales(): Promise<SaleWithDetails[]> {
    const sales = Array.from(this.sales.values());
    const salesWithDetails: SaleWithDetails[] = [];

    for (const sale of sales) {
      const customer = sale.customerId ? this.customers.get(sale.customerId) : undefined;
      const user = this.users.get(sale.userId)!;
      const items = Array.from(this.saleItems.values())
        .filter(item => item.saleId === sale.id)
        .map(item => ({
          ...item,
          product: this.products.get(item.productId)!,
        }));

      salesWithDetails.push({
        ...sale,
        customer,
        user,
        items,
      });
    }

    return salesWithDetails.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getSale(id: string): Promise<SaleWithDetails | undefined> {
    const sale = this.sales.get(id);
    if (!sale) return undefined;

    const customer = sale.customerId ? this.customers.get(sale.customerId) : undefined;
    const user = this.users.get(sale.userId)!;
    const items = Array.from(this.saleItems.values())
      .filter(item => item.saleId === sale.id)
      .map(item => ({
        ...item,
        product: this.products.get(item.productId)!,
      }));

    return {
      ...sale,
      customer,
      user,
      items,
    };
  }

  async createSale(insertSale: InsertSale, items: InsertSaleItem[]): Promise<Sale> {
    const id = randomUUID();
    const transactionId = `TXN-${Date.now().toString(36).toUpperCase()}`;
    
    const sale: Sale = {
      ...insertSale,
      id,
      transactionId,
      createdAt: new Date(),
    };
    
    this.sales.set(id, sale);

    // Create sale items and update product stock
    for (const item of items) {
      const saleItem: SaleItem = {
        ...item,
        id: randomUUID(),
        saleId: id,
      };
      this.saleItems.set(saleItem.id, saleItem);

      // Update product stock
      await this.updateProductStock(item.productId, -item.quantity, insertSale.userId, "sale");
    }

    // Update customer total purchases if customer exists
    if (sale.customerId) {
      const customer = this.customers.get(sale.customerId);
      if (customer) {
        const updatedCustomer = {
          ...customer,
          totalPurchases: (parseFloat(customer.totalPurchases) + parseFloat(sale.total)).toString(),
          loyaltyPoints: customer.loyaltyPoints + Math.floor(parseFloat(sale.total)),
        };
        this.customers.set(sale.customerId, updatedCustomer);
      }
    }

    return sale;
  }

  async getSalesByDateRange(startDate: Date, endDate: Date): Promise<SaleWithDetails[]> {
    const allSales = await this.getSales();
    return allSales.filter(sale => 
      sale.createdAt >= startDate && sale.createdAt <= endDate
    );
  }

  async getRecentTransactions(limit: number = 10): Promise<SaleWithDetails[]> {
    const sales = await this.getSales();
    return sales.slice(0, limit);
  }

  // Inventory methods
  async getInventoryAdjustments(): Promise<InventoryAdjustment[]> {
    return Array.from(this.inventoryAdjustments.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createInventoryAdjustment(insertAdjustment: InsertInventoryAdjustment): Promise<InventoryAdjustment> {
    const id = randomUUID();
    const adjustment: InventoryAdjustment = {
      ...insertAdjustment,
      id,
      createdAt: new Date(),
    };
    this.inventoryAdjustments.set(id, adjustment);
    return adjustment;
  }

  // Dashboard methods
  async getDashboardStats(): Promise<DashboardStats> {
    const today = new Date();
    const startOfDay = new Date(today.getFullYear(), today.getMonth(), today.getDate());
    const yesterday = new Date(startOfDay);
    yesterday.setDate(yesterday.getDate() - 1);
    
    const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const lastMonth = new Date(startOfMonth);
    lastMonth.setMonth(lastMonth.getMonth() - 1);

    const todaySales = await this.getSalesByDateRange(startOfDay, today);
    const yesterdaySales = await this.getSalesByDateRange(yesterday, startOfDay);
    const thisMonthSales = await this.getSalesByDateRange(startOfMonth, today);
    const lastMonthSales = await this.getSalesByDateRange(lastMonth, startOfMonth);

    const todayTotal = todaySales.reduce((sum, sale) => sum + parseFloat(sale.total), 0);
    const yesterdayTotal = yesterdaySales.reduce((sum, sale) => sum + parseFloat(sale.total), 0);
    const salesGrowth = yesterdayTotal > 0 ? ((todayTotal - yesterdayTotal) / yesterdayTotal) * 100 : 0;

    const totalProducts = this.products.size;
    const lastMonthProductCount = totalProducts; // Simplified for demo
    const productGrowth = lastMonthProductCount > 0 ? ((totalProducts - lastMonthProductCount) / lastMonthProductCount) * 100 : 0;

    const lowStockProducts = await this.getLowStockProducts();
    const activeCustomers = Array.from(this.customers.values()).filter(c => c.isActive).length;

    return {
      todaySales: todayTotal,
      salesGrowth,
      totalProducts,
      productGrowth,
      lowStockItems: lowStockProducts.length,
      activeCustomers,
      customerGrowth: 8.1, // Simplified for demo
    };
  }

  async getTopSellingProducts(limit: number = 10): Promise<(Product & { soldQuantity: number; revenue: number })[]> {
    const productSales = new Map<string, { quantity: number; revenue: number }>();

    // Calculate sales for each product
    for (const saleItem of this.saleItems.values()) {
      const existing = productSales.get(saleItem.productId) || { quantity: 0, revenue: 0 };
      productSales.set(saleItem.productId, {
        quantity: existing.quantity + saleItem.quantity,
        revenue: existing.revenue + parseFloat(saleItem.totalPrice),
      });
    }

    // Get products with sales data
    const productsWithSales = Array.from(productSales.entries())
      .map(([productId, sales]) => {
        const product = this.products.get(productId);
        return product ? {
          ...product,
          soldQuantity: sales.quantity,
          revenue: sales.revenue,
        } : null;
      })
      .filter(Boolean)
      .sort((a, b) => b!.soldQuantity - a!.soldQuantity)
      .slice(0, limit);

    return productsWithSales as (Product & { soldQuantity: number; revenue: number })[];
  }
}

export const storage = new MemStorage();
