# Overview

This is a Retail Point of Sale (POS) and Inventory Management system built as a full-stack web application. The system is designed for small to medium businesses to track sales, manage inventory, handle customer relationships, and generate reports. It features a modern React frontend with a Node.js/Express backend, using PostgreSQL for data persistence and Drizzle ORM for database operations.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **UI Library**: Shadcn/ui components built on top of Radix UI primitives
- **Styling**: Tailwind CSS with custom design system variables
- **State Management**: TanStack Query (React Query) for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Forms**: React Hook Form with Zod validation
- **Authentication**: Context-based authentication with localStorage session persistence

## Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ES modules
- **API Design**: RESTful API structure with route-based organization
- **Database ORM**: Drizzle ORM for type-safe database operations
- **Authentication**: BCrypt for password hashing with session-based auth
- **Development**: Hot module replacement via Vite integration

## Database Design
- **Database**: PostgreSQL with connection via Neon Database serverless driver
- **Schema Management**: Drizzle Kit for migrations and schema management
- **Core Entities**: 
  - Users (role-based access control)
  - Products (with SKU, barcode, and category relationships)
  - Categories and Suppliers
  - Customers and Sales transactions
  - Inventory tracking with stock movements
- **Relationships**: Foreign key relationships between products, categories, suppliers, and sales data

## Component Architecture
- **Layout Components**: Sidebar navigation and top bar with search functionality
- **Page Components**: Route-specific components for dashboard, POS, products, inventory, etc.
- **UI Components**: Reusable design system components from Shadcn/ui
- **Business Logic**: Custom hooks and context providers for state management
- **Form Handling**: Standardized form components with validation schemas

## Authentication & Authorization
- **User Roles**: Admin, Manager, and Cashier role-based permissions
- **Session Management**: Client-side session storage with server-side validation
- **Protected Routes**: HOC pattern for route protection based on authentication status
- **Password Security**: BCrypt hashing with salt rounds for secure password storage

# External Dependencies

## Database Services
- **Neon Database**: Serverless PostgreSQL hosting for production database
- **Drizzle ORM**: Type-safe ORM with PostgreSQL dialect configuration

## UI and Styling
- **Radix UI**: Headless UI components for accessibility and functionality
- **Tailwind CSS**: Utility-first CSS framework with custom design tokens
- **Font Awesome**: Icon library for consistent iconography
- **Google Fonts**: Inter font family for typography

## Development Tools
- **Vite**: Build tool and development server with HMR
- **TypeScript**: Static type checking across frontend and backend
- **ESBuild**: Fast bundling for production builds
- **PostCSS**: CSS processing with Tailwind integration

## Form and Data Management
- **React Hook Form**: Form state management and validation
- **Zod**: Schema validation library for type-safe data validation
- **TanStack Query**: Server state management, caching, and synchronization
- **Date-fns**: Date manipulation and formatting utilities

## Authentication
- **BCrypt**: Password hashing and comparison
- **Connect PG Simple**: PostgreSQL session store for Express sessions

## Development Environment
- **Replit Plugins**: Runtime error overlay, cartographer, and dev banner for Replit development
- **TSX**: TypeScript execution for development server
- **Wouter**: Lightweight React router for client-side navigation